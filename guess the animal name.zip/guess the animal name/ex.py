import json
from random import *
def lire():
    try:
        with open ("animaux.json","r") as filin:
            animaux=json.load(filin)
    except:
        print("ops")
    return animaux

print("la liste d'animaux:")
animaux=lire()
print(animaux)
 


for i in range (4):
    
    while True:
        print(animaux.keys())
        pref=input("donner moi votre animal prefere: ")
        pref=pref.lower()
        if pref in animaux.keys():
            print("le choix existe",pref)
        else:
            print("n'existe pas")
            break
        choix=randint(1,3)
        score=0
        if(choix==1):
            femelle=input("nom de femelle: ")
            femelle=femelle.lower()
            if (femelle ==animaux[pref][0]):
                score=score+1
                print("correct")
            else:
                 print("fausse")
                 print("la bonne reponse: ",animaux[pref][0])
            animaux.pop(pref)
        
        if(choix==2):
            petit=input("nom de petit: ")
            petit=petit.lower()
            if (petit ==animaux[pref][1]):
                score=score+1
                print("correct")
            else:
                print("fausse")
                print("la bonne reponse: ",animaux[pref][1])
            animaux.pop(pref)
        if(choix==3):
            cri=input("nom de cri: ")
            cri=cri.lower()
            if (cri==animaux[pref][2]):
                score=score+1
                print("correct")
            else:
                print("fausse")
                print("la bonne reponse: ",animaux[pref][2])
            animaux.pop(pref)
        print("le score: ",score)
    
   
        

    