liste = [] 
for i in range(0, 5):
    liste.append(i)
print(liste)
del(liste[2]) 
print(liste) 
liste.remove(3) 
print(liste) 