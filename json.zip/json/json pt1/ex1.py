animaux = [' girafe ',' tigre','singe ',' souris ']
print ("{} et {} ". format (animaux [2] , animaux [-2]))
print ("{} et {} ". format (animaux [1] , animaux [-1]))