print (list ( range (10)))
print (list ( range (15 ,20)))
print (list ( range (0 ,1000 ,200)))