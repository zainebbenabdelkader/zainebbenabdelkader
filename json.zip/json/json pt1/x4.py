from math import*
liste=[]
carre=[]
for i in range(4,20):
    if (i%2==0):
        liste.append(i)
        carre.append(sqrt(i))
print(liste)
print(carre)