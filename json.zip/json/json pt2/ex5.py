import os
try:
    with open("notes.txt","r") as filout, open("notes2.txt","w") as filin:
        for note in filout:
            if (int(note) < 10):
                filin.write("refuse: "+str(note))
            else:
                filin.write("admis: "+str(note))
except:
    print("opps")
ch=os.getcwd()
print(ch)