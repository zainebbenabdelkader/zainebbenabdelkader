import sys, os
print(os.getcwd())
fd='c:/python'
try:
    os.chdir(fd)
    print("cwd: ",os.getcwd())
except:
    print("oppps: ",sys.exc_info())
