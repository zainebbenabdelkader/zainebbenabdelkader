l=[]
n=int(input("donner n= "))
for i in range(n):
    x=float(input("donner x ="))
    if ( (x>=0.00 )and (x<=20.00)):
        l.append(str(x))
print("la liste",l)

try:
    with open("notes.txt","w") as filout:
        print(filout)
        for note in l:
            filout.write(note + "\n")
except:
    print("opps pb avec le fichier")