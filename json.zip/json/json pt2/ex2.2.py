try:
    with open("zoo.txt","r") as filin:
        for ligne in filin:
            print(ligne)
except:
    print("oppps")
