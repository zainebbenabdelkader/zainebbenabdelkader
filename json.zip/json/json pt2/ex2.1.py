try:
    with open("zoo.txt","r") as filin:
        ligne=filin.readline()
        while ligne !="":
            print(ligne)
            ligne=filin.readline()
except:
    print("oppps")