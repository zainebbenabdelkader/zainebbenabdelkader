try:
    with open("zoo.txt","r") as fichier1, open("zoo2.txt","w") as fichier2:
        for ligne in fichier1:
            fichier2.write("* "+ligne)
except:
    print("opps")