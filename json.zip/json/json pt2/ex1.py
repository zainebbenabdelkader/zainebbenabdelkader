animaux =[{"poisson","abeille","chat"}]
try:
    with open("zoo.json","w") as filout:
        print(filout)
        for animal in animaux:
            filout.write(animal + "\n")
except:
    print("opps pb avec le fichier")
 #use "write" only once